#include "IndicatorPinEV.h"
#include <Arduino.h>
#include "TimerThree.h"
#include "TimerOne.h"

uint8_t E_EVOLVECTOR = 13;
uint8_t D_EVOLVECTOR = 12;
uint8_t DP_EVOLVECTOR = 11;
uint8_t C_EVOLVECTOR = 10;
uint8_t G_EVOLVECTOR = 9;
uint8_t B_EVOLVECTOR = 8;
uint8_t F_EVOLVECTOR = 7;
uint8_t A_EVOLVECTOR = 6;
uint8_t DIG1_EVOLVECTOR = 5;
uint8_t DIG2_EVOLVECTOR = 4;
uint8_t DIG3_EVOLVECTOR = 3;
uint8_t DIG4_EVOLVECTOR = 2;

unsigned char first_digit_evolvector;
unsigned char second_digit_evolvector;
unsigned char third_digit_evolvector;
unsigned char fourth_digit_evolvector;
boolean dot_first_digit_evolvector=false;
boolean dot_second_digit_evolvector=false;
boolean dot_third_digit_evolvector=false;
unsigned char digit_number_evolvector=1;
int divider_evolvector;
int push_evolvector;
int number_mantis_evolvector;
bool empty_evolvector;

void set_number_evolvector()
{
  if(digit_number_evolvector==1)
  {
    digitalWrite(DIG4_EVOLVECTOR,LOW); 
    create_symbol_evolvector(first_digit_evolvector);
    digitalWrite(DIG1_EVOLVECTOR,HIGH);
  }
  else if(digit_number_evolvector==2)
  {
    digitalWrite(DIG1_EVOLVECTOR,LOW); 
    create_symbol_evolvector(second_digit_evolvector);
    digitalWrite(DIG2_EVOLVECTOR,HIGH);
  }
  else if(digit_number_evolvector==3)
  {
    digitalWrite(DIG2_EVOLVECTOR,LOW); 
    create_symbol_evolvector(third_digit_evolvector);
    digitalWrite(DIG3_EVOLVECTOR,HIGH);
  }
  else if(digit_number_evolvector==4)
  {
    digitalWrite(DIG3_EVOLVECTOR,LOW); 
    create_symbol_evolvector(fourth_digit_evolvector);
    digitalWrite(DIG4_EVOLVECTOR,HIGH);
    digit_number_evolvector=0;    
  }

  digit_number_evolvector++;
}

void IndicatorPinEV(uint8_t timer, uint8_t a, uint8_t f, uint8_t b, uint8_t g, uint8_t c, uint8_t d, uint8_t e, uint8_t dp, uint8_t dig1, uint8_t dig2, uint8_t dig3, uint8_t dig4)
{
  E_EVOLVECTOR = e;
  D_EVOLVECTOR = d;
  DP_EVOLVECTOR = dp;
  C_EVOLVECTOR = c;
  G_EVOLVECTOR = g;
  B_EVOLVECTOR = b;
  F_EVOLVECTOR = f;
  A_EVOLVECTOR = a;
  DIG1_EVOLVECTOR = dig1;
  DIG2_EVOLVECTOR = dig2;
  DIG3_EVOLVECTOR = dig3;
  DIG4_EVOLVECTOR = dig4;
  pinMode(E_EVOLVECTOR, OUTPUT);
  pinMode(D_EVOLVECTOR, OUTPUT);
  pinMode(DP_EVOLVECTOR, OUTPUT);
  pinMode(C_EVOLVECTOR, OUTPUT);
  pinMode(G_EVOLVECTOR, OUTPUT);
  pinMode(B_EVOLVECTOR, OUTPUT);
  pinMode(F_EVOLVECTOR, OUTPUT);
  pinMode(A_EVOLVECTOR, OUTPUT);
  pinMode(DIG1_EVOLVECTOR, OUTPUT);
  pinMode(DIG2_EVOLVECTOR, OUTPUT);
  pinMode(DIG3_EVOLVECTOR, OUTPUT);
  pinMode(DIG4_EVOLVECTOR, OUTPUT);
  if (timer == 1) {
    Timer1.initialize(1000);
    Timer1.attachInterrupt(set_number_evolvector);
  } else {
    Timer3.initialize(1000);
    Timer3.attachInterrupt(set_number_evolvector);
  }
} 

void create_symbol_evolvector(unsigned char digit_evolvector) {
  switch (digit_evolvector) {
    case 0:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,LOW);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 1:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,LOW);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,LOW);
        break;
   case 2:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,LOW);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 3:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 4:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,LOW);
        break;
   case 5:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,LOW);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 6:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,LOW);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
    case 7:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,LOW);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
    case 8:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
    case 9:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
    case 10:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(DP_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,LOW);
        digitalWrite(G_EVOLVECTOR,LOW);
        digitalWrite(B_EVOLVECTOR,LOW);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,LOW);
        break;
    case 11:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(C_EVOLVECTOR,LOW);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,LOW);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,LOW);
        break;    
    case 12:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,LOW);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 13:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,LOW);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,LOW);
        break;
   case 14:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,LOW);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 15:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 16:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,LOW);
        break;
   case 17:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,LOW);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
   case 18:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,LOW);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
    case 19:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,LOW);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,LOW);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,LOW);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
    case 20:
        digitalWrite(E_EVOLVECTOR,HIGH);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
    case 21:
        digitalWrite(E_EVOLVECTOR,LOW);
        digitalWrite(D_EVOLVECTOR,HIGH);
        digitalWrite(DP_EVOLVECTOR,HIGH);
        digitalWrite(C_EVOLVECTOR,HIGH);
        digitalWrite(G_EVOLVECTOR,HIGH);
        digitalWrite(B_EVOLVECTOR,HIGH);
        digitalWrite(F_EVOLVECTOR,HIGH);
        digitalWrite(A_EVOLVECTOR,HIGH);
        break;
  } 
}

void indicator_set(int number_evolvector)
{
  divider_evolvector=1000;
  empty_evolvector=true;
  push_evolvector=0;
  digitalWrite(DP_EVOLVECTOR,LOW);
  if(number_evolvector>=0)
  {
  while(divider_evolvector)
  {
    
    push_evolvector=number_evolvector/divider_evolvector;
    push_evolvector=push_evolvector%10;
    
    
    if(push_evolvector==0&&empty_evolvector)    
    {
      if(divider_evolvector==1000)
      {
        first_digit_evolvector=10;
      }
      else if(divider_evolvector==100)
      {
        second_digit_evolvector=10;
      }
      else if(divider_evolvector==10)
      {
        third_digit_evolvector=10;
      }
      else if(divider_evolvector==1)
      {
        fourth_digit_evolvector=0;
      }
    }
    else
    {
      empty_evolvector=false;
      if(divider_evolvector==1000)
      {
        first_digit_evolvector=push_evolvector;
      }
      else if(divider_evolvector==100)
      {
        second_digit_evolvector=push_evolvector;
      }
      else if(divider_evolvector==10)
      {
        third_digit_evolvector=push_evolvector;
      }
      else if(divider_evolvector==1)
      {
        fourth_digit_evolvector=push_evolvector;
      }
    }
    divider_evolvector=divider_evolvector/10;
  }
  }
  
  else if(number_evolvector<0)
  {
  number_evolvector=abs(number_evolvector);
  while(divider_evolvector)
  {    
    push_evolvector=number_evolvector/divider_evolvector;
    push_evolvector=push_evolvector%10;    
    
    if(push_evolvector==0&&empty_evolvector)    
    {
      if(divider_evolvector==1000)
      {
        first_digit_evolvector=11;
      }
      else if(divider_evolvector==100)
      {
        first_digit_evolvector=10;
        second_digit_evolvector=11;
      }
      else if(divider_evolvector==10)
      {   
        first_digit_evolvector=10;
        second_digit_evolvector=10;     
        third_digit_evolvector=11;
      }      
    }
    else
    {
      empty_evolvector=false;
      
      if(divider_evolvector==100)
      {
        second_digit_evolvector=push_evolvector;
      }
      else if(divider_evolvector==10)
      {
        third_digit_evolvector=push_evolvector;
      }
      else if(divider_evolvector==1)
      {
        fourth_digit_evolvector=push_evolvector;
      }
    }
    divider_evolvector=divider_evolvector/10;
  }
  }
}

void indicator_set_float(float number_evolvector, int dot_digit_evolvector=0)
{
  boolean dot_first_digit_evolvector=false;
  boolean dot_second_digit_evolvector=false;
  boolean dot_third_digit_evolvector=false;
  
  divider_evolvector=1000;
  push_evolvector=0;
  
  if(number_mantis_evolvector>=0)
  {

  if(dot_digit_evolvector==1)
  {
    number_mantis_evolvector=int(number_evolvector*1000);
    dot_first_digit_evolvector=true; 
  }
  else if(dot_digit_evolvector==2)
  {
    number_mantis_evolvector=int(number_evolvector*100);
    dot_second_digit_evolvector=true;
  }
  else if(dot_digit_evolvector==3)
  {
    number_mantis_evolvector=int(number_evolvector*10);
    dot_third_digit_evolvector=true;
  }
    
  else if(int(number_evolvector)/10==0)
  {
    number_mantis_evolvector=int(number_evolvector*1000);
    dot_first_digit_evolvector=true;   
  }
  else if(int(number_evolvector)/100==0)
  {
    number_mantis_evolvector=int(number_evolvector*100);
    dot_second_digit_evolvector=true;    
  }
  else if(int(number_evolvector)/1000==0)
  {
    number_mantis_evolvector=int(number_evolvector*10);
    dot_third_digit_evolvector=true;    
  }  
  else
  {
    number_mantis_evolvector=int(number_evolvector);
  }
  
  while(divider_evolvector)
  {    
    push_evolvector=number_mantis_evolvector/divider_evolvector;
    push_evolvector=push_evolvector%10;
    
      if(divider_evolvector==1000)
      {
        if(dot_first_digit_evolvector)
        {
          first_digit_evolvector=push_evolvector+12;
        }
        else
        {
          first_digit_evolvector=push_evolvector;
        }
      }
      else if(divider_evolvector==100)
      {
        if(dot_second_digit_evolvector)
        {
          second_digit_evolvector=push_evolvector+12;
        }
        else
        {
          second_digit_evolvector=push_evolvector;
        }
      }
      else if(divider_evolvector==10)
      {
        if(dot_third_digit_evolvector)
        {
          third_digit_evolvector=push_evolvector+12;
        }
        else
        {
          third_digit_evolvector=push_evolvector;
        }
      }
      else if(divider_evolvector==1)
      {
        fourth_digit_evolvector=push_evolvector;
      }
    
    divider_evolvector=divider_evolvector/10;
  }
  } 

  if(number_mantis_evolvector<0)
  {
  dot_first_digit_evolvector=false;
  dot_second_digit_evolvector=false;
  dot_third_digit_evolvector=false;
  divider_evolvector=1000;
  first_digit_evolvector=11;
  
  if(dot_digit_evolvector==1)
  {
    number_mantis_evolvector=int(number_evolvector*1000);
    dot_first_digit_evolvector=true; 
  }
  else if(dot_digit_evolvector==2)
  {
    number_mantis_evolvector=int(number_evolvector*100);
    dot_second_digit_evolvector=true;
  }
  else if(dot_digit_evolvector==3)
  {
    number_mantis_evolvector=int(number_evolvector*10);
    dot_third_digit_evolvector=true;
  }

  else if(int(number_evolvector)/10==0)
  {
    number_mantis_evolvector=abs(int(number_evolvector*100));
    dot_second_digit_evolvector=true;  
  }
  else if(int(number_evolvector)/100==0)
  {
    number_mantis_evolvector=abs(int(number_evolvector*10));
    dot_third_digit_evolvector=true;   
  }  
  else
  {
    number_mantis_evolvector=abs(int(number_evolvector));
  }
  
  while(divider_evolvector)
  {    
    push_evolvector=number_mantis_evolvector/divider_evolvector;
    push_evolvector=push_evolvector%10;
            
      if(divider_evolvector==100)
      {
        if(dot_second_digit_evolvector)
        {
          second_digit_evolvector=push_evolvector+12;
        }
        else
        {
          second_digit_evolvector=push_evolvector;
        }
      }
      else if(divider_evolvector==10)
      {
        if(dot_third_digit_evolvector)
        {
          third_digit_evolvector=push_evolvector+12;
        }
        else
        {
          third_digit_evolvector=push_evolvector;
        }
      }
      else if(divider_evolvector==1)
      {
        fourth_digit_evolvector=push_evolvector;
      }
    divider_evolvector=divider_evolvector/10;
  }
  } 
}