#ifndef IndicatorPinEV_h
#define IndicatorPinEV_h

#include <Arduino.h>
#include "TimerThree.h"
#include "TimerOne.h"

#define T1 1
#define T3 3

void IndicatorPinEV(uint8_t timer, uint8_t a, uint8_t f, uint8_t b, uint8_t g, uint8_t c, uint8_t d, uint8_t e, uint8_t dp, uint8_t dig1, uint8_t dig2, uint8_t dig3, uint8_t dig4);
void set_number_evolvector();
void create_symbol_evolvector(unsigned char digit_evolvector);
void indicator_set(int number_evolvector);
void indicator_set_float(float number_evolvector, int dot_digit_evolvector=0);


#endif



