#include "ColorSensorEv.h"


ColorSensorEv::ColorSensorEv()
{    
    Wire.begin();
    COLOR_ADRESS=0x6A;
}

ColorSensorEv::ColorSensorEv(unsigned char new_adress)
{    
    Wire.begin();
    COLOR_ADRESS=new_adress;
}

void ColorSensorEv::readColor(uint16_t &red, uint16_t &green, uint16_t &blue)
{
    unsigned char red_l;
    unsigned char red_h;
    unsigned char green_l;
    unsigned char green_h;
    unsigned char blue_l;
    unsigned char blue_h;

    Wire.requestFrom(COLOR_ADRESS, 6, true);
    red_l = Wire.read();
    red_h = Wire.read();
    green_l = Wire.read();
    green_h = Wire.read();
    blue_l = Wire.read();
    blue_h = Wire.read();

    red = (red_h<<8)|red_l;
    green = (green_h<<8)|green_l;
    blue = (blue_h<<8)|blue_l;
}

void ColorSensorEv::newAdress(unsigned char color_adress)
{
    Wire.beginTransmission(COLOR_ADRESS);
    Wire.write(NEW_ADRESS_CODE); 
    Wire.write(color_adress);     
    Wire.endTransmission(); 
}