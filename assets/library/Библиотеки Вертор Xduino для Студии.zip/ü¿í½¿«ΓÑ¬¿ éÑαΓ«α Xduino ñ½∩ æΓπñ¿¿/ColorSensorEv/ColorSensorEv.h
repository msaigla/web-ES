#ifndef ColorSensorEv_H
#define ColorSensorEv_H

#define NEW_ADRESS_CODE 0x65

#include "Arduino.h"
#include "Wire.h"

class ColorSensorEv
{
    private:
        unsigned char COLOR_ADRESS;
    public:
        ColorSensorEv();
        ColorSensorEv(unsigned char new_adress);
        void readColor(uint16_t &red, uint16_t &green, uint16_t &blue);
        void newAdress(unsigned char encoder_adress);
};

#endif