/*

    описание............

*/

#include "Arduino.h"
#include "controlAllPins.h"

void pinsDefault()
{
    for (byte i = 0; i <= 13; i++) {
        pinMode(i, OUTPUT);
        digitalWrite(i, LOW);
    }
    analogWrite(A0, LOW);
    analogWrite(A1, LOW);
    analogWrite(A2, LOW);
    analogWrite(A3, LOW);
    analogWrite(A4, LOW);
    analogWrite(A5, LOW);
}
