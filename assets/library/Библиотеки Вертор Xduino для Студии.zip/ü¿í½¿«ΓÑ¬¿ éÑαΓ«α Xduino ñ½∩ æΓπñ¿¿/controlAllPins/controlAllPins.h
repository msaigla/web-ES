/*

	описание............

*/


#ifndef ALLPINS_h
#define ALLPINS_h

#include "Arduino.h"


void pinsDefault();

#endif