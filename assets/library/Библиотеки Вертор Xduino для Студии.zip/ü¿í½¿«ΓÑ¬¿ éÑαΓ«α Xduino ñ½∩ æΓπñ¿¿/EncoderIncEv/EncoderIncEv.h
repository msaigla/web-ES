#ifndef EncoderIncEv_H
#define EncoderIncEv_H

#define NEW_ADRESS_CODE 0x65
#define RESET_OBOROT_CODE 0x75
#define RECORD_CODE 0x85
#define RESET_EEPROM_CODE 0x95

#include "Arduino.h"
#include "Wire.h"

class EncoderIncEv
{
    private:
        unsigned char ENC_ADRESS;
    public:
        EncoderIncEv();
        EncoderIncEv(unsigned char new_adress);
        int read();
        void reset();
        void record();
        void drop();
        void newAdress(unsigned char encoder_adress);
};

#endif