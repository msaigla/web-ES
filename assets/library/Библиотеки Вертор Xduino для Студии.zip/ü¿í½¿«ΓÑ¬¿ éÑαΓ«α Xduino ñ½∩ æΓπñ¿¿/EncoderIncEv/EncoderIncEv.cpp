#include "EncoderIncEv.h"


EncoderIncEv::EncoderIncEv()
{    
    Wire.begin();
    ENC_ADRESS=0x5A;
}

EncoderIncEv::EncoderIncEv(unsigned char new_adress)
{    
    Wire.begin();
    ENC_ADRESS=new_adress;
}

int EncoderIncEv::read()
{
    Wire.requestFrom(ENC_ADRESS, 2, true);
    int data = Wire.read();     // принять байт как символ
    data=data<<8;        
    data=data|Wire.read();
    return data;
}

void EncoderIncEv::reset()
{
    Wire.beginTransmission(ENC_ADRESS);
    Wire.write(RESET_EEPROM_CODE);          
    Wire.endTransmission(); 
}

void EncoderIncEv::record()
{
    Wire.beginTransmission(ENC_ADRESS);
    Wire.write(RECORD_CODE);          
    Wire.endTransmission(); 
}

void EncoderIncEv::drop()
{
    Wire.beginTransmission(ENC_ADRESS);
    Wire.write(RESET_OBOROT_CODE);          
    Wire.endTransmission(); 
}

void EncoderIncEv::newAdress(unsigned char encoder_adress)
{
    Wire.beginTransmission(ENC_ADRESS);
    Wire.write(NEW_ADRESS_CODE); 
    Wire.write(encoder_adress);     
    Wire.endTransmission(); 
}