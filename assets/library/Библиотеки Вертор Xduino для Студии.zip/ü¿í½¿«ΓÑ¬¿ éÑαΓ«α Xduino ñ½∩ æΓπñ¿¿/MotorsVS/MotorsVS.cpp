#include "MotorsVS.h"


MotorsVS_I2C::MotorsVS_I2C(uint8_t motor)
{
    Wire.begin();
    num_motor = motor;
    polarity=true;
}

MotorsVS_I2C::MotorsVS_I2C(uint8_t motor, bool mot_polarity)
{
    Wire.begin();
    num_motor = motor;
    polarity=mot_polarity;
}

void MotorsVS_I2C::motorStop()
{
    switch (num_motor)
    {
    case 1:
        Wire.beginTransmission(MOTOR1_I2C);
        Wire.write(0x00);
        Wire.write(0x00);
        Wire.endTransmission();
        break;
    case 2:
        Wire.beginTransmission(MOTOR2_I2C);
        Wire.write(0x00);
        Wire.write(0x00);
        Wire.endTransmission();
        break;
    case 3:
        Wire.beginTransmission(MOTOR3_I2C);
        Wire.write(0x00);
        Wire.write(0x00);
        Wire.endTransmission();
    case 4:
        Wire.beginTransmission(MOTOR4_I2C);
        Wire.write(0x00);
        Wire.write(0x00);
        Wire.endTransmission();
    default:
        break;
    }
}

void MotorsVS_I2C::motorForward(byte speed)
{    
    byte ratio;
    if(polarity)
    { ratio=0x02;}
    else
    { ratio=0x01;}
    if(speed>100)
    {speed=100;}
    else if(speed<0)
    {speed=0;}
    speed=map(speed,0,100,6,61);
    switch (num_motor)
    {
    case 1:
        Wire.beginTransmission(MOTOR1_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();

        Wire.beginTransmission(MOTOR1_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    case 2:
	    Wire.beginTransmission(MOTOR2_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();
		
        Wire.beginTransmission(MOTOR2_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    case 3:
        Wire.beginTransmission(MOTOR3_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();
	
        Wire.beginTransmission(MOTOR3_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    case 4:
        Wire.beginTransmission(MOTOR4_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();
		
        Wire.beginTransmission(MOTOR4_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    default:
        break;
    }
}


void MotorsVS_I2C::motorBackward(byte speed)
{       
    byte ratio;
    if(polarity)
    { ratio=0x01;}
    else
    { ratio=0x02;}
    if(speed>100)
    {speed=100;}
    else if(speed<0)
    {speed=0;}
    speed=map(speed,0,100,6,61);
    switch (num_motor)
    {
    case 1:
        Wire.beginTransmission(MOTOR1_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();

        Wire.beginTransmission(MOTOR1_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    case 2:
        Wire.beginTransmission(MOTOR2_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();
		
        Wire.beginTransmission(MOTOR2_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    case 3:
        Wire.beginTransmission(MOTOR3_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();

        Wire.beginTransmission(MOTOR3_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    case 4:
        Wire.beginTransmission(MOTOR4_I2C);
        Wire.write(0x01);
        Wire.write(0x80);
        Wire.endTransmission();
		
        Wire.beginTransmission(MOTOR4_I2C);
        Wire.write(0x00);
        Wire.write(speed<<2|ratio);
        Wire.endTransmission();
        break;
    default:
        break;
    }
}

void MotorsVS_I2C::SmoothForward(byte speed)
{
for(int evolvector_speeds=0;evolvector_speeds<=speed;evolvector_speeds=evolvector_speeds+2)
  {
    motorForward(evolvector_speeds);
    delay(10);
  }
}

void MotorsVS_I2C::SmoothBackward(byte speed)
{
for(int evolvector_speeds=0;evolvector_speeds<=speed;evolvector_speeds=evolvector_speeds+2)
  {
    motorForward(evolvector_speeds);
    delay(10);
  }
}

void MotorsVS_I2C::motorSpeed(int16_t speed)
{
    if (speed == 0) {
        motorStop();
    } else {
        if (speed < -100) {
            speed = -100;
        } else if (speed > 100) {
            speed = 100;
        }
        if (speed > 0) {            
            // byte speed_b = byte(62 / 100 * speed + 6);
            if(polarity)
            {motorForward(speed);}
            else
            {motorBackward(speed);}
            
        } else {
            // byte speed_b = byte(62 / 100 * (speed * -1) + 6)
            speed *= -1;
            if(polarity)
            {motorBackward(speed);}
            else
            {motorForward(speed);}            
        }
    }
}

void MotorsVS_I2C::motorSpeed(int16_t speed, bool reverse)
{
    if (reverse) speed *= -1;
    if (speed == 0) {
        motorStop();
    } else {
        if (speed < -100) {
            speed = -100;
        } else if (speed > 100) {
            speed = 100;
        }
        if (speed > 0) {            
            // byte speed_b = byte(62 / 100 * speed + 6);
            if(polarity)
            {motorForward(speed);}
            else
            {motorBackward(speed);}
            
        } else {
            // byte speed_b = byte(62 / 100 * (speed * -1) + 6)
            speed *= -1;
            if(polarity)
            {motorBackward(speed);}
            else
            {motorForward(speed);}            
        }
    }
}