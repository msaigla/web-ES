#ifndef RGBLightEV_H
#define RGBLightEV_H

#define NEW_ADRESS_CODE 0x65
#define SET_COLOR_CODE 0x10

#include "Arduino.h"
#include "Wire.h"
#include <inttypes.h>

class RGBLightEV
{
     private:
	unsigned char RGB_ADRESS;
     public:
        RGBLightEV();
        RGBLightEV(unsigned char new_adress);
        void color_set(unsigned char red, unsigned char green, unsigned char blue);
        void newAdress(unsigned char new_rgb_adress);
};


#endif