#include "RGBLightEV.h"

RGBLightEV::RGBLightEV()
{
    Wire.begin();
    RGB_ADRESS=0x4A;
}

RGBLightEV::RGBLightEV(unsigned char new_adress)
{    
    Wire.begin();
    RGB_ADRESS=new_adress;
}


void RGBLightEV::color_set(unsigned char red, unsigned char green, unsigned char blue)
{  
  Wire.beginTransmission(RGB_ADRESS);
  Wire.write(SET_COLOR_CODE);
  Wire.write(red);
  Wire.write(green);
  Wire.write(blue);
  Wire.endTransmission();
}

void RGBLightEV::newAdress(unsigned char new_rgb_adress)
{  
  Wire.beginTransmission(RGB_ADRESS);
  Wire.write(NEW_ADRESS_CODE);
  Wire.write(new_rgb_adress);
  Wire.endTransmission();
}