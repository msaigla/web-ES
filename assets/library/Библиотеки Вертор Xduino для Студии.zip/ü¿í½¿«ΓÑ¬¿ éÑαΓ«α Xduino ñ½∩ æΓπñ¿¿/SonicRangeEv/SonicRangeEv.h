#ifndef SonicRangeEv_h
#define SonicRangeEv_h

#include <Arduino.h>
#include <Wire.h>


#define PORT7 7
#define PORT6 6

class SonicRangeEv
{
  private:
    unsigned long time_us=0;
    uint8_t trig_s = 18;
    uint8_t echo_s = 13;
  public:
    SonicRangeEv(uint8_t port);
    SonicRangeEv(uint8_t trig, uint8_t echo);
    int read();
    
};


#endif



