











#ifndef Ev_RTC_h																						
#define Ev_RTC_h																						
																											
#define	RTC_UNDEFINED 0																						
																											
#if defined(ARDUINO) && (ARDUINO >= 100)																	
#include <Arduino.h>																						
#else																										
#include <WProgram.h>																						
#endif																										
																																																
																											
class Ev_RTC_BASE{																					
	public:																									
		virtual void	begin				(void);															
		virtual uint8_t	funcReadTimeIndex	(uint8_t);														
		virtual void	funcWriteTimeIndex	(uint8_t, uint8_t);												
};																											
																											
																																														
#include "Ev_RTC_DS1307.h"																			
																											
class Ev_RTC{																							
	public:																									
	/**	Конструктор класса **/																				
		Ev_RTC(uint8_t i, uint8_t j=SS, uint8_t k=SCK, uint8_t n=MOSI){								
			switch(i){																					
				#ifdef RTC_ENABLE_DS1307																	
				case RTC_DS1307: objClass = new Ev_RTC_DS1307; break;									
				#endif																						
			}																								
		}																									
	/**	Пользовательские функции **/																		
		void	begin		(void)					{objClass -> begin(); gettime();}						
		void	period		(uint8_t i)				{valPeriod=i; valPeriod*=60000;}						
		void	blinktime	(uint8_t i, float j=1)	{valBlink=i; valFrequency=uint32_t(1000/j);}			
		void	gettime		(void)					{gettime("");}											
		char*	gettime		(String);																		
		char*	gettime		(const char*);																	
		void	settime		(int, int=-1, int=-1, int=-1, int=-1, int=-1, int=-1);							
	   uint32_t	gettimeUnix	(void)					{gettime(""); return Unix;}								
		void	settimeUnix	(uint32_t);																		
																											
	/**	Переменные доступные для пользователя **/															
		uint8_t	seconds					=	0;																
		uint8_t	minutes					=	0;																
		uint8_t	hours					=	1;																
		uint8_t	Hours					=	0;																
		uint8_t	midday					=	0;																
		uint8_t	day						=	1;																
		uint8_t	weekday					=	0;																
		uint8_t	month					=	1;																
		uint8_t	year					=	0;																
	   uint32_t	Unix					=	0;																
																											
	/**	Внутренние переменные **/																			
		Ev_RTC_BASE*	objClass;																		
		char*	charReturn				=	(char*) malloc(1);												
  const char* 	charInput				=	"waAdhHimsyMDY";												
  const char*	charMidday				=	"ampmAMPM";														
  const char*	charDayMon				=	"SunMonTueWedThuFriSatJanFebMarAprMayJunJulAugSepOctNovDec";	
		uint8_t	arrCalculationTime[7];																		
		uint8_t	valBlink				=	0;																
	   uint32_t	valFrequency			=	1000;															
		uint8_t	valCentury				=	21;																
	   uint16_t	valPeriod				=	0;																
	   uint32_t	valRequest				=	0;																
	private:																								
	/**	Внутренние функции **/																				
		void	funcReadTime			(void);																
		void	funcWriteTime			(int, int, int, int, int, int, int);								
		uint8_t	funcConvertCodeToNum	(uint8_t i)	{return (i >> 4)*10 + (i & 0x0F);}						
		uint8_t	funcConvertNumToCode	(uint8_t i)	{return ((i/10) << 4) + (i%10);}						
		void	funcSetMoreTime			(void){hours=(Hours%12)?(Hours%12):12; midday=(Hours<12)?0:1;}		
		void	funcCalculationTime		(void);																
	   uint32_t	funcCalculationUnix		(void);																
		void	funcFillChar			(uint8_t, uint8_t, uint8_t, uint8_t);								
};																											
																											
#endif																										