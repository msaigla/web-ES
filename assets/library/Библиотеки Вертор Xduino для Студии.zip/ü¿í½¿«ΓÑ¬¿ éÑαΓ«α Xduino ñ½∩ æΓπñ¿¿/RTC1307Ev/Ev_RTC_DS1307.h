#ifndef Ev_RTC_DS1307_h																	
#define Ev_RTC_DS1307_h																	
#define	RTC_DS1307 2																			
#include "Ev_RTC_I2C.h"																	
																								
class Ev_RTC_DS1307: public Ev_RTC_BASE{											
	public:																						
	/**	функции доступные пользователю **/														

		void	begin(void){																	

					objI2C.begin(100);															

					varI=objI2C.readByte(valAddress, 0x00); if( varI & 0b10000000                         ){objI2C.writeByte(valAddress, 0x00, (varI&~0b10000000)            );}	
					varI=objI2C.readByte(valAddress, 0x02); if( varI & 0b01000000                         ){objI2C.writeByte(valAddress, 0x02, (varI&~0b01000000)            );}	
					varI=objI2C.readByte(valAddress, 0x07); if((varI & 0b00000011) || !(varI & 0b00010000)){objI2C.writeByte(valAddress, 0x07, (varI&~0b00000011)|0b00010000 );}	
		}																						
																								

		uint8_t	funcReadTimeIndex(uint8_t i){													
					delay(1);																	
					return objI2C.readByte(valAddress, arrTimeRegAddr[i]) & arrTimeRegMack[i];	
		}																						
																								

		void	funcWriteTimeIndex(uint8_t i, uint8_t j){										
					varI=funcReadTimeIndex(i);													
					j |= ~arrTimeRegMack[i] & varI;												
					j &=  arrTimeRegMack[i] | varI;												
					objI2C.writeByte(valAddress, arrTimeRegAddr[i], j);							
		}																						
																								
	private:																					
	/**	Внутренние переменные **/																
		Ev_I2C objI2C;																	
		uint8_t	valAddress				=	 0x68;												
		uint8_t	arrTimeRegAddr[7]		=	{0x00,0x01,0x02,0x04,0x05,0x06,0x03};				
		uint8_t	arrTimeRegMack[7]		=	{0x7F,0x7F,0x3F,0x3F,0x1F,0xFF,0x07};				
		uint8_t	varI;																			
};																								
																								
#endif																							