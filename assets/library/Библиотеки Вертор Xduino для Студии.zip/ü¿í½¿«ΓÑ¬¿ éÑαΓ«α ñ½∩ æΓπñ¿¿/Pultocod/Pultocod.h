#ifndef BTLib_h
#define BTLib_h
#include <Arduino.h>

class Pultocod
{
    public:
        Pultocod(long speed);
        String read();
        char read_full();
        void write(String msg);
        void writeln(String msg);
};
#endif