#include "Pultocod.h"

Pultocod::Pultocod(long speed)
{
    Serial1.begin(speed);
    Serial.begin(9600);
}

String Pultocod::read()
{
    String mystr;
    char str[12];
    int i = 0;
    boolean flag = 0;
    while (!flag) {
        if (Serial1.available())
        {

            str[i] = Serial1.read();

            if (str[i] == '/')
            {
                i = 0;
                flag = 1;
            }
            else
            {
                mystr = String(mystr) + str[i];
                i++;
            }
        }
    }

    return mystr;
}

char Pultocod::read_full()
{
    if (Serial1.available())
    {
        return Serial1.read();        
    }
    else
    {
      return 0;
    }
}

void Pultocod::write(String msg)
{
    Serial1.print(msg);
}

void Pultocod::writeln(String msg)
{
    Serial1.println(msg);
}