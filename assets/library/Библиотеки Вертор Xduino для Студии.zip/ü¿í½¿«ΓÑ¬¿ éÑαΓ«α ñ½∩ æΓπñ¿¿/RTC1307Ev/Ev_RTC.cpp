#include "Ev_RTC.h"


char*	Ev_RTC::gettime(String i){char j[i.length()+1]; i.toCharArray(j, i.length()); j[i.length()]=0; return gettime(j);}
char*	Ev_RTC::gettime(const char* i){
			uint8_t j, k, n; bool f;																		
			if(valRequest > millis()){valRequest=0;}														

			if(valPeriod == 0)											{funcReadTime();}else				
			if(valRequest == 0 || (valPeriod+valRequest <= millis()))	{funcReadTime();}else				
																		{funcCalculationTime();}			
			funcSetMoreTime();																				

			n=strlen(i)+1;																					
			for(j=0; j<strlen(i);         j++)	{															
			for(k=0; k<strlen(charInput); k++)	{															
			if (i[j]==charInput[k])				{															
				if(k>0){n++;} if(k>9){n++;} if(k>11){n++;}													
			}}}

			free(charReturn);																				
			charReturn = (char*) malloc(n);																	

			n=0;																							
			for(j=0; j<strlen(i); j++)	{																	
				if(i[j]==charInput[0]	/*	w	*/	)	{funcFillChar( weekday		,0,n,7);	n+=1;}else	
				if(i[j]==charInput[1]	/*	a	*/	)	{funcFillChar( midday*2		,2,n,8);	n+=2;}else	
				if(i[j]==charInput[2]	/*	A	*/	)	{funcFillChar((midday+2)*2	,2,n,8);	n+=2;}else	
				if(i[j]==charInput[3]	/*	d	*/	)	{funcFillChar( day			,1,n,4);	n+=2;}else	
				if(i[j]==charInput[4]	/*	h	*/	)	{funcFillChar( hours		,1,n,3);	n+=2;}else	
				if(i[j]==charInput[5]	/*	H	*/	)	{funcFillChar( Hours		,1,n,3);	n+=2;}else	
				if(i[j]==charInput[6]	/*	i	*/	)	{funcFillChar( minutes		,1,n,2);	n+=2;}else	
				if(i[j]==charInput[7]	/*	m	*/	)	{funcFillChar( month		,1,n,5);	n+=2;}else	
				if(i[j]==charInput[8]	/*	s	*/	)	{funcFillChar( seconds		,1,n,1);	n+=2;}else	
				if(i[j]==charInput[9]	/*	y	*/	)	{funcFillChar( year			,1,n,6);	n+=2;}else	
				if(i[j]==charInput[10]	/*	M	*/	)	{funcFillChar((month+6)*3	,3,n,5);	n+=3;}else	
				if(i[j]==charInput[11]	/*	D	*/	)	{funcFillChar( weekday*3	,3,n,7);	n+=3;}else	
				if(i[j]==charInput[12]	/*	Y	*/	)	{funcFillChar( year			,4,n,6);	n+=4;}else	
														{charReturn[n]=i[j];					n+=1;}		
			}	charReturn[n]='\0'; return charReturn;														
}


void		Ev_RTC::funcFillChar(uint8_t i, uint8_t j, uint8_t n, uint8_t k){							
			bool f=valBlink==k; if((millis()%valFrequency)<(valFrequency/2)){f=false;}						
			switch (j){
				/* 1 знак	*/	case 0: if(i>6 ){i=6; }	charReturn[n]=f?32:i+48;																																		break;
				/* 2 знака	*/	case 1: if(i>99){i=99;}	charReturn[n]=f?32:i/10+48;					charReturn[n+1]=f?32:i%10+48;																						break;
				/* AM / PM	*/	case 2: if(i>6 ){i=6; }	charReturn[n]=f?32:charMidday[i];			charReturn[n+1]=f?32:charMidday[i+1];																				break;
				/* дн / мес	*/	case 3: if(i>54){i=54;}	charReturn[n]=f?32:charDayMon[i];			charReturn[n+1]=f?32:charDayMon[i+1];		charReturn[n+2]=f?32:charDayMon[i+2];									break;
				/* 4 знака	*/	case 4: if(i>99){i=99;}	charReturn[n]=f?32:(valCentury-1)/10+48;	charReturn[n+1]=f?32:(valCentury-1)%10+48;	charReturn[n+2]=f?32:i/10+48;			charReturn[n+3]=f?32:i%10+48;	break;
			}
}


void	Ev_RTC::settime(int i1, int i2, int i3, int i4, int i5, int i6, int i7){						
			funcWriteTime(i1, i2, i3, i4, i5, i6, i7);														
			funcReadTime();																					
			funcSetMoreTime();																				
}


void	Ev_RTC::settimeUnix(uint32_t i){																
			uint32_t j;	uint8_t k; bool f=true;																
			seconds		=  i          % 60;																	
			i			= (i-seconds) / 60;																	
			minutes		=  i          % 60;																	
			i			= (i-minutes) / 60;																	
			Hours		=  i          % 24;																	
			i			= (i-Hours)   / 24;																	
			j			=  0; while((((j+1)*365)+((j+2)/4))<=i){j++;}										
			weekday		= (i+4) % 7;																		
			i			=  i - (j*365) - ((j+1)/4);															
			valCentury	= ((1970+j)/100)+1;																	
			year		=  (1970+j)%100;																	
			k			= ((1970+j)%4)==0?29:28;															
			month		= 0; while(f){month++; j=month; j=(((j+1)%2)^(j<8))?31:(j==2?k:30); if(i>=j){i-=j;}else{f=false;}}
			day			= i+1;																				
		
			settime(seconds, minutes, Hours, day, month, year, weekday);
}


void	Ev_RTC::funcReadTime(void){																	
			seconds    = arrCalculationTime[0] = funcConvertCodeToNum(objClass -> funcReadTimeIndex(0));	
			minutes    = arrCalculationTime[1] = funcConvertCodeToNum(objClass -> funcReadTimeIndex(1));	
			Hours      = arrCalculationTime[2] = funcConvertCodeToNum(objClass -> funcReadTimeIndex(2));	
			day        = arrCalculationTime[3] = funcConvertCodeToNum(objClass -> funcReadTimeIndex(3));	
			month      = arrCalculationTime[4] = funcConvertCodeToNum(objClass -> funcReadTimeIndex(4));	
			year       = arrCalculationTime[5] = funcConvertCodeToNum(objClass -> funcReadTimeIndex(5));	
			weekday    = arrCalculationTime[6] = funcConvertCodeToNum(objClass -> funcReadTimeIndex(6))-1;	
			Unix       = funcCalculationUnix();																
			valRequest = millis();																			
}


void	Ev_RTC::funcWriteTime(int i1, int i2, int i3, int i4, int i5, int i6, int i7){				
			if(i1<=60 && i1>=0){objClass -> funcWriteTimeIndex(0, funcConvertNumToCode(i1  ));}				
			if(i2<=60 && i2>=0){objClass -> funcWriteTimeIndex(1, funcConvertNumToCode(i2  ));}				
			if(i3<=23 && i3>=0){objClass -> funcWriteTimeIndex(2, funcConvertNumToCode(i3  ));}				
			if(i4<=31 && i4>=1){objClass -> funcWriteTimeIndex(3, funcConvertNumToCode(i4  ));}				
			if(i5<=12 && i5>=1){objClass -> funcWriteTimeIndex(4, funcConvertNumToCode(i5  ));}				
			if(i6<=99 && i6>=0){objClass -> funcWriteTimeIndex(5, funcConvertNumToCode(i6  ));}				
			if(i7<= 6 && i7>=0){objClass -> funcWriteTimeIndex(6, funcConvertNumToCode(i7+1));}				
}


void	Ev_RTC::funcCalculationTime(void){															
			uint32_t i=(millis()-valRequest)/1000;															
			uint8_t	 j=30 + ( (arrCalculationTime[4] + (arrCalculationTime[4]>7?1:0)) % 2 );				
			if(arrCalculationTime[4]==2){j=28+((((uint16_t)valCentury-1)*100+arrCalculationTime[5])%4?0:1);}
			i+=arrCalculationTime[0]; seconds = i%60;		i/=60;											
			i+=arrCalculationTime[1]; minutes = i%60;		i/=60;											
			i+=arrCalculationTime[2]; Hours   = i%24;		i/=24;											
			                          weekday = arrCalculationTime[6]+i; if(weekday>6){weekday=0;}			
			i+=arrCalculationTime[3]; day     = i%(j+1);	i/=(j+1);	day+=i;								
			i+=arrCalculationTime[4]; month   = i%13;		i/=13;		month+=i;							
			i+=arrCalculationTime[5]; year    = i%100;														
			                          Unix    = funcCalculationUnix();										
}


uint32_t Ev_RTC::funcCalculationUnix(void){															
			uint32_t i;																						
			uint32_t j = (uint32_t)(valCentury-1) * 100 + year;												
			i  = j - 1970;																					
			i  = i * 365 + ((i+1)/4);																		
			i += (month-1)*30 + ( (month + (month<9?0:1) )/2 );												
			i -= month>2? (j%4==0?1:2) : 0;																	
			i += day-1;																						
			i *= 86400;																						
			i += (uint32_t)Hours * 3600 + (uint32_t)minutes * 60 + seconds;									
			return i;																						
}
