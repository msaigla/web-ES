#ifndef Ev_I2C_h																
#define Ev_I2C_h																
																					

		#define Ev_I2C_SW														
#if (!defined(pin_SW_SDA) || !defined(pin_SW_SCL))									
		#undef  Ev_I2C_SW														
	#if defined(ESP8266) || defined(ESP32)											
		#include <Wire.h>															
		#define pin_SW_SDA 255														
		#define pin_SW_SCL 255														
		#define Ev_I2C_TW														
	#elif defined(TwoWire_h)														
		#define pin_SW_SDA 255														
		#define pin_SW_SCL 255														
		#define Ev_I2C_TW														
	#elif (defined(SDA) && defined(SCL))											
		#define pin_SW_SDA SDA														
		#define pin_SW_SCL SCL														
		#define Ev_I2C_HW														
	#elif (defined(PIN_WIRE_SDA) && defined(PIN_WIRE_SCL))							
		#define pin_SW_SDA PIN_WIRE_SDA												
		#define pin_SW_SCL PIN_WIRE_SCL												
		#define Ev_I2C_HW														
	#elif (defined(SDA1) && defined(SCL1))											
		#define pin_SW_SDA SDA1														
		#define pin_SW_SCL SCL1														
		#define Ev_I2C_HW_1													
	#else																			
		#define pin_SW_SDA 255														
		#define pin_SW_SCL 255														
	#endif																			
#endif																				
																					
class Ev_I2C_BASE{															
	public:																			

		virtual void	begin		(uint32_t);										
		virtual uint8_t	readByte	(uint8_t, uint8_t         );					
		virtual bool	writeByte	(uint8_t, uint8_t, uint8_t);					
		virtual uint8_t	readByte	(uint8_t                  );					
		virtual bool	writeByte	(uint8_t,          uint8_t);					
		virtual bool	readBytes	(uint8_t, uint8_t, uint8_t*, uint8_t);			
		virtual bool	writeBytes	(uint8_t, uint8_t, uint8_t*, uint8_t);			
		virtual bool	readBytes	(uint8_t,          uint8_t*, uint8_t);			
		virtual bool	writeBytes	(uint8_t,          uint8_t*, uint8_t);			

		virtual uint8_t getType		(void);											
		virtual bool	checkAddress(uint8_t);										

		virtual bool	start		(void);											
		virtual bool	reStart		(void);											
		virtual void	stop		(void);											
		virtual bool	sendID		(uint8_t, bool);								
		virtual bool	setByte		(uint8_t);										
		virtual uint8_t	getByte		(bool);											
	private:																		
		virtual bool	setSCL		(bool);											
		virtual void	setSDA		(bool);											
		virtual bool	getSDA		(void);											
};																					
																					
class Ev_I2C: public Ev_I2C_BASE{										
	public:																			
																					
	/**	ОСНОВНЫЕ ФУНКЦИИ: **/														
																					

		void	begin(uint32_t speed){												





				#if defined(Ev_I2C_TW)										
				
					Wire.setClock(speed*1000L);  		                            
					Wire.begin();													
				#elif defined(Ev_I2C_HW)										
				
					pinMode(pin_SDA, INPUT ); digitalWrite(pin_SDA, HIGH);			
					pinMode(pin_SCL, INPUT ); digitalWrite(pin_SCL, HIGH);			
					TWBR=((F_CPU/(speed*1000L))-16)/2;								
					if(TWBR<10){TWBR=10;}											
					TWSR&=(~(_BV(TWPS1)|_BV(TWPS0)));								
				#elif defined(Ev_I2C_SW)										
				
					port_SDA	=	digitalPinToPort	(pin_SDA);					
					port_SCL	=	digitalPinToPort	(pin_SCL);					
					mask_SDA	=	digitalPinToBitMask	(pin_SDA);					
					mask_SCL	=	digitalPinToBitMask	(pin_SCL);					
					mod_SDA		=	portModeRegister	(port_SDA);					
					mod_SCL		=	portModeRegister	(port_SCL);					
					inp_SDA		=	portInputRegister	(port_SDA);					
					inp_SCL		=	portInputRegister	(port_SCL);					
					out_SDA		=	portOutputRegister	(port_SDA);					
					out_SCL		=	portOutputRegister	(port_SCL);					
					setSCL(1);														
					setSDA(1);														
				#endif																
		}																			
																					

		uint8_t	readByte(uint8_t adr, uint8_t reg){									
				uint8_t i=0; readBytes(adr, reg, &i, 1); return i;					
		}																			
																					

		uint8_t	readByte(uint8_t adr){												
				uint8_t i=0; readBytes(adr, &i, 1); return i;						
		}																			
																					

		bool	writeByte(uint8_t adr, uint8_t reg, uint8_t data){					
				return writeBytes(adr, reg, &data, 1);								
		}																			
																					

		bool	writeByte(uint8_t adr, uint8_t data){								
				return writeBytes(adr, &data, 1);									
		}																			
																					

		bool	readBytes(uint8_t adr, uint8_t reg, uint8_t *data, uint8_t sum){	
				#if defined(Ev_I2C_TW)										
				
					uint8_t										i=0;				
					Wire.beginTransmission(adr);									
					Wire.write(reg);												
					i=Wire.endTransmission(false); if(i){return	0;}					
					if(!Wire.requestFrom( adr, sum ))	{return	i;}					
					while(Wire.available() && i<sum){data[i]=Wire.read(); i++;}		
					while(Wire.available()){Wire.read();}return	i==sum;				
				#else																
				
					uint8_t										i=0;				
					if (			start	()		)	{		i=1;				
					if (			sendID	(adr,0)	)	{		i=2;				
					if (			setByte	(reg)	)	{		i=3;				
					if (			reStart	()		)	{		i=4;				
					if (			sendID	(adr,1)	)	{		i=5;				
					while(sum>0){	*data=getByte(sum>1); 							
									data++; sum--;									
					#if defined(Ev_I2C_HW)									
					if (sum)	{	if(TWSR&0xF8!=0x50)	{		i=0;}}				
					else		{	if(TWSR&0xF8!=0x58)	{		i=0;}}				
					#endif															
					}}}}}}			stop	();			return	i==5;				
				#endif																
		}																			
																					

		bool	readBytes(uint8_t adr, uint8_t *data, uint8_t sum){					
				#if defined(Ev_I2C_TW)										
				
					uint8_t										i=0;				
					if(!Wire.requestFrom( adr, sum ))	{return	i;}					
					while(Wire.available() && i<sum){data[i]=Wire.read(); i++;}		
					while(Wire.available()){Wire.read();}return	i==sum;				
				#else																
				
					uint8_t										i=0;				
					if (			start	()		)	{		i=1;				
					if (			sendID	(adr,1)	)	{		i=2;				
					while(sum>0){	*data=getByte(sum>1); 							
									data++; sum--;									
					#if defined(Ev_I2C_HW)									
					if (sum)	{	if(TWSR&0xF8!=0x50)	{		i=0;}}				
					else		{	if(TWSR&0xF8!=0x58)	{		i=0;}}				
					#endif															
					}}}				stop	();			return	i==2;				
				#endif																
		}																			
																					

		bool	writeBytes(uint8_t adr, uint8_t reg, uint8_t *data, uint8_t sum){	
				#if defined(Ev_I2C_TW)										
				
					uint8_t										i=0;				
					Wire.beginTransmission(adr);									
					Wire.write(reg);												
					Wire.write(data, sum);											
					i = Wire.endTransmission();			return	i==0;				
				#else																
				
					uint8_t										i=0;				
					if (			start	()		)	{		i=1;				
					if (			sendID	(adr,0)	)	{		i=2;				
					if (			setByte	(reg)	)	{		i=3;				
					while(sum>0){if(!setByte(*data	))	{		i=0;}				
									data++; sum--;									
					}}}}			stop	();			return	i==3;				
				#endif																
		}																			
																					

		bool	writeBytes(uint8_t adr, uint8_t *data, uint8_t sum){				
				#if defined(Ev_I2C_TW)										
				
					uint8_t										i=0;				
					Wire.beginTransmission(adr);									
					Wire.write(data, sum);											
					i = Wire.endTransmission();			return	i==0;				
				#else																
				
					uint8_t										i=0;				
					if (			start	()		)	{		i=1;				
					if (			sendID	(adr,0)	)	{		i=2;				
					while(sum>0){if(!setByte(*data	))	{		i=0;}				
									data++; sum--;									
					}}}				stop	();			return	i==2;				
				#endif																
		}																			
																					
	/**	ДОПОЛНИТЕЛЬНЫЕ ФУНКЦИИ: **/													
																					

		uint8_t getType(void){														
				#if defined(Ev_I2C_TW)										
					return 4;														
				#elif defined(Ev_I2C_HW)										
					return 3;														
				#elif defined(Ev_I2C_HW_1)									
					return 2;														
				#elif defined(Ev_I2C_SW)										
					return 1;														
				#else																
					return 0;														
				#endif																
		}																			
																					

		bool	checkAddress(uint8_t adr){											
				#if defined(Ev_I2C_TW)										
				
					uint8_t										i=0;				
					Wire.beginTransmission(adr);									
					i=Wire.endTransmission();			return	i==0;				
				#else																
				
					uint8_t										i=0;				
					if (			start	()		)	{		i=1;				
					if (			sendID	(adr,0)	)	{		i=2;				
					}}				stop	();			return	i==2;				
				#endif																
		}																			
																					
	/**	ФУНКЦИИ НИЖНЕГО УРОВНЯ: **/													
																					

		bool	start(void){														





				#if defined(Ev_I2C_HW)										
				
					uint16_t i=60000L;												
					TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWSTA);						
					while((!(TWCR & _BV(TWINT))) && i){i--;}						
					if((TWSR & 0xF8)==0x08){return true;}							
					return false;													
				#elif defined(Ev_I2C_SW)										
				
					bool i=	setSCL(1); 												
							setSDA(0);												
							setSCL(0);												
					return i;														
				#else																
				
					return false;													
				#endif																
		}																			
																					

		bool	reStart(void){														





				#if defined(Ev_I2C_HW)										
				
					uint16_t i=60000L;												
					TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWSTA);						
					while((!(TWCR & _BV(TWINT))) && i){i--;}						
					if((TWSR & 0xF8)==0x10){return true;}							
					return false;													
				#elif defined(Ev_I2C_SW)										
				
					return start();													
				#else																
				
					return false;													
				#endif																
		}																			
																					

		void	stop(void){															





				#if defined(Ev_I2C_HW)										
				
					uint16_t i=60000L;												
					TWCR = _BV(TWINT) | _BV(TWEN) | _BV(TWSTO);						
					while((!(TWCR & _BV(TWSTO))) && i){i--;}						
				
					delayMicroseconds(20);											
				#elif defined(Ev_I2C_SW)										
				
					setSDA(0);														
					setSCL(1);														
					setSDA(1);														
				#endif																
		}																			
																					

		bool	sendID(uint8_t adr, bool rw){										





				#if defined(Ev_I2C_HW)										
				
					uint16_t i=60000L;												
					TWDR = (adr<<1)+rw;												
					TWCR = _BV(TWINT) | _BV(TWEN);									
					while((!(TWCR & _BV(TWINT))) && i){i--;}						
					if((TWSR & 0xF8)==0x40 &&  rw){return true;}					
					if((TWSR & 0xF8)==0x18 && !rw){return true;}					
					return false;													
				#elif defined(Ev_I2C_SW)										
				
					bool    i=true;													
					uint8_t j=7;													
					while(j){ j--;													
							setSDA(adr & bit(j));									
						if(!setSCL(1) )									{i=false;}	
							setSCL(0);												
					}		setSDA(rw);												
						if(!setSCL(1) )									{i=false;}	
							setSCL(0);												
							setSDA(1);												
						if(!setSCL(1) )									{i=false;}	
						if( getSDA( ) )									{i=false;}	
							setSCL(0);												
					return i;														
				#else																
				
					return false;													
				#endif																
		}																			
																					

		bool	setByte(uint8_t data){												





				#if defined(Ev_I2C_HW)										
				
					uint16_t i=60000L;												
					TWDR = data;													
					TWCR = _BV(TWINT) | _BV(TWEN);									
					while((!(TWCR & _BV(TWINT))) && i){i--;}						
					if((TWSR & 0xF8)==0x28){return true;}							
					return false;													
				#elif defined(Ev_I2C_SW)										
				
					bool    i=true;													
					uint8_t j=8;													
					while(j){ j--;													
							setSDA(data & bit(j));									
						if(!setSCL(1) )									{i=false;}	
							setSCL(0);												
					}		setSDA(1);												
						if(!setSCL(1) )									{i=false;}	
						if( getSDA( ) )									{i=false;}	
							setSCL(0);												
					return i;														
				#else																
				
					return false;													
				#endif																
		}																			
																					

		uint8_t	getByte(bool ack){													





				#if defined(Ev_I2C_HW)										
				
					uint16_t i=60000L;												
					TWCR = _BV(TWINT) | _BV(TWEN) |  ack<<TWEA;						
					while((!(TWCR & _BV(TWINT))) && i){i--;}						
					if((TWSR & 0xF8)==0x50 &&  ack){return TWDR;}					
					if((TWSR & 0xF8)==0x58 && !ack){return TWDR;}					
					return 0;														
				#elif defined(Ev_I2C_SW)										
				
					bool    i=true;													
					uint8_t j=8;													
					uint8_t k=0;													
							setSDA(1);												
					while(j){ j--;													
						if(!setSCL(1) )									{i=false;}	
						if( getSDA( ) )	{ k |= (1<<j); }							
							setSCL(0);												
					}		setSDA(!ack);											
						if(!setSCL(1) )									{i=false;}	
							setSCL(0);												
					return i?k:0;													
				#else																
				
					return 0;														
				#endif																
		}																			
																					
	private:																		
		uint8_t			  pin_SDA = pin_SW_SDA;										
		uint8_t			  pin_SCL = pin_SW_SCL;										
		uint8_t			  port_SDA;													
		uint8_t			  port_SCL;													
		uint8_t			  mask_SDA;													
		uint8_t			  mask_SCL;													
		volatile uint8_t *mod_SDA;													
		volatile uint8_t *mod_SCL;													
		volatile uint8_t *inp_SDA;													
		volatile uint8_t *inp_SCL;													
		volatile uint8_t *out_SDA;													
		volatile uint8_t *out_SCL;													
																					

		bool	setSCL(bool f){														
					uint16_t i=60000L;												
					if(!f)	{*mod_SCL |=  mask_SCL; *out_SCL &= ~mask_SCL;}			
					else	{*mod_SCL &= ~mask_SCL; *out_SCL |=  mask_SCL;			
					          while((*inp_SCL & mask_SCL)==0 && i){i--;}  }			
					return i;														
		}																			
																					

		void	setSDA(bool f){														
					if(!f)	{*mod_SDA |=  mask_SDA; *out_SDA &= ~mask_SDA;}			
					else	{*mod_SDA &= ~mask_SDA; *out_SDA |=  mask_SDA;}			
		}																			
																					

		bool	getSDA(void){ return (*inp_SDA & mask_SDA);	}						
};																					
																					
#endif																				