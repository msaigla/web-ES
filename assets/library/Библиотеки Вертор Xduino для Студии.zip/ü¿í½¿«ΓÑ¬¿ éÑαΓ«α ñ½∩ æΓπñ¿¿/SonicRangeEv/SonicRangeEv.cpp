#include "SonicRangeEv.h"
#include <Arduino.h>
#include <Wire.h>

SonicRangeEv::SonicRangeEv(uint8_t port)
{
  switch (port)
  {
  case 7:
    trig_s = 18;
    echo_s = 13;
    break;
  case 6:
    trig_s = 19;
    echo_s = 5;
    break;
  default:
    trig_s = 18;
    echo_s = 13;
    break;
  }
  pinMode(trig_s,OUTPUT);
  pinMode(echo_s,INPUT);
  digitalWrite(trig_s, HIGH); 
}

SonicRangeEv::SonicRangeEv(uint8_t trig, uint8_t echo)
{
  trig_s = trig;
  echo_s = echo;
  pinMode(trig_s,OUTPUT);
  pinMode(echo_s,INPUT);
  digitalWrite(trig_s, HIGH); 
}

int SonicRangeEv::read()
{
  digitalWrite(trig_s, LOW);
  delay(5);
  digitalWrite(trig_s, HIGH);
  while(digitalRead(echo_s)==true)
  {
    ; 
  }
  time_us=micros();
  while(digitalRead(echo_s)==false)
  {
    ; 
  }
  return ((micros()-time_us)/60);
}