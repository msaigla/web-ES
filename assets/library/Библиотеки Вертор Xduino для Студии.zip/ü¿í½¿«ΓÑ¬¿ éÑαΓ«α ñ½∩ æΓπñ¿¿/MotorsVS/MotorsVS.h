/*

	описание............

*/


#ifndef MotorsVS_H
#define MotorsVS_H

#define MOTOR1_I2C 0x62
#define MOTOR2_I2C 0x66
#define MOTOR3_I2C 0x60
#define MOTOR4_I2C 0x68

#include "Arduino.h"
#include "Wire.h"

class MotorsVS_I2C
{
    private:
        uint8_t num_motor;
	bool polarity;
    public:
	MotorsVS_I2C(uint8_t motor);
        MotorsVS_I2C(uint8_t motor, bool mot_polarity);
        void motorStop();
        void motorForward(byte speed);
        void motorBackward(byte speed);
        void SmoothForward(byte speed);
        void SmoothBackward(byte speed);
        void motorSpeed(int16_t speed);
        void motorSpeed(int16_t speed, bool reverse);
};

#endif