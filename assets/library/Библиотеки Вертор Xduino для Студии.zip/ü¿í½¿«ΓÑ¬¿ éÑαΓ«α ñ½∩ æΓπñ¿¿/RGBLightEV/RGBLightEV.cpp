#include "RGBLightEV.h"


void color_set(char red, char green, char blue)
{
  Wire.begin();
  Wire.beginTransmission(0x4A);
  Wire.write(red);
  Wire.write(green);
  Wire.write(blue);
  Wire.endTransmission();
}