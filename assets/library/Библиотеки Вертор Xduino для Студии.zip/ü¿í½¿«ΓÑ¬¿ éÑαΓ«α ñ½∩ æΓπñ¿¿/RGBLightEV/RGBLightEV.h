#ifndef RGBLightEV_H
#define RGBLightEV_H

#include "Arduino.h"
#include "Wire.h"
#include <inttypes.h>

void color_set(char red, char green, char blue);

#endif